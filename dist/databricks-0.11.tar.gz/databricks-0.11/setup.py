from setuptools import setup, find_packages

setup(
    name="databricks", 
    version="0.11",
    description="biblioteca databricks",
    author="DDRE",
    packages=find_packages()
)