# Databricks Lib

Para instalar esta biblioteca, faça o download do arquivo dist/databricks-0.11.tar.gz e rode o comando

```bash
    pip install ./databricks-0.11.tar.gz
```

A documentação está dentro da pasta docs/exemples

![Alt text](image.png)